#!/bin/bash
python encode.py $1 $2