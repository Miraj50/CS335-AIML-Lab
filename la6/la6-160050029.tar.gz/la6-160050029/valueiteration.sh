#!/bin/bash
python valueiteration.py $1
