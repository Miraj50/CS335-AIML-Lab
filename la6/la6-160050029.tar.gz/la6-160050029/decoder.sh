#!/bin/bash
python decode.py $1 $2 $3